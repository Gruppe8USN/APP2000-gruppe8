import React from "react";
import { BsTwitter } from "react-icons/bs";
import { SiLinkedin } from "react-icons/si";
import { BsYoutube } from "react-icons/bs";
import { FaFacebookF } from "react-icons/fa";

const Footer = () => {
  return (
    <div className="footer-wrapper">
      <div className="footer-section-one">
        {/* Omitted the logo container */}
        <div className="footer-icons">
          <a href="https://twitter.com/WeAreFarmFresh" target="_blank" rel="noopener noreferrer">
            <BsTwitter />
          </a>
          <a href="https://www.linkedin.com/company/farm-fresh-uae/" target="_blank" rel="noopener noreferrer">
            <SiLinkedin />
          </a>
          <a href="https://www.youtube.com/FarmFreshDairyProduce" target="_blank" rel="noopener noreferrer">
            <BsYoutube />
          </a>
          <a href="https://www.facebook.com/farmfresh.gmg" target="_blank" rel="noopener noreferrer">
            <FaFacebookF />
          </a>
        </div>
      </div>
      <div className="footer-section-two">
        <div className="footer-section-columns">
          <span>+9714 339 7279</span>
          <span>ffresh@gmg.com</span>
        </div>
      </div>
    </div>
  );
};

export default Footer;
